$(document).ready(function(){
 $('.slider').slick(
 {
	arrows: false,
	autoplay: true
 });
 });
